<template>
<vue-plyr>
  <div class="plyr__video-embed">
    <iframe
      src="https://www.youtube.com/embed/CqnPcJZr1RQ"
      allowfullscreen allowtransparency allow="autoplay">
    </iframe>
  </div>
</vue-plyr>
</template>

<script>
	
export default {
	data(){
		return {
			
		}
	}
}
</script>

<style>

</style>